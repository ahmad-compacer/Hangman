/**
 * 
 * @author akhalil
 * Numbers if accounts
 */
public class Configuration {
	
	/**
	 * 
	 */
	public static int numberAccounts = 10;
}
